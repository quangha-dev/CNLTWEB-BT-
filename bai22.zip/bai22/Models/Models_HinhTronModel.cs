﻿namespace bai22.Models
{
    public class Models_HinhTronModel
    {
        public double BanKinh { get; set; }
        public double DienTich { get; set; }
        public double ChuVi { get; set; }
        public double DuongKinh { get; set; }
    }
}
